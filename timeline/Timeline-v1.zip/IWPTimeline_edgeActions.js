
(function($,Edge,compId){var Composition=Edge.Composition,Symbol=Edge.Symbol;
//Edge symbol: 'stage'
(function(symbolName){Symbol.bindElementAction(compId,symbolName,"${_begin}","click",function(sym,e){sym.stop('1966');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_end}","click",function(sym,e){sym.stop('2013');sym.$("YearText").html("2013");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",0,function(sym,e){sym.$("YearText").html("1966");sym.stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",500,function(sym,e){sym.$("YearText").html("1967");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",1000,function(sym,e){sym.$("YearText").html("1968");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_pause}","click",function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_play}","click",function(sym,e){sym.play();});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M1967}","click",function(sym,e){sym.stop('1967');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M1968}","click",function(sym,e){sym.stop('1968');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M1969}","click",function(sym,e){sym.stop('1969');});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",1500,function(sym,e){sym.$("YearText").html("1969");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",2000,function(sym,e){sym.$("YearText").html("1970");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",2500,function(sym,e){sym.$("YearText").html("1971");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",3000,function(sym,e){sym.$("YearText").html("1972");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",3500,function(sym,e){sym.$("YearText").html("1973");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",4000,function(sym,e){sym.$("YearText").html("1974");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",4500,function(sym,e){sym.$("YearText").html("1975");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",5000,function(sym,e){sym.$("YearText").html("1976");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",5500,function(sym,e){sym.$("YearText").html("1977");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",6000,function(sym,e){sym.$("YearText").html("1978");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",6500,function(sym,e){sym.$("YearText").html("1979");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",7000,function(sym,e){sym.$("YearText").html("1980");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",7500,function(sym,e){sym.$("YearText").html("1981");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",8000,function(sym,e){sym.$("YearText").html("1982");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",8500,function(sym,e){sym.$("YearText").html("1983");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",9000,function(sym,e){sym.$("YearText").html("1984");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",9500,function(sym,e){sym.$("YearText").html("1985");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",10000,function(sym,e){sym.$("YearText").html("1986");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",10500,function(sym,e){sym.$("YearText").html("1987");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",11000,function(sym,e){sym.$("YearText").html("1988");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",11500,function(sym,e){sym.$("YearText").html("1989");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",12000,function(sym,e){sym.$("YearText").html("1990");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",12500,function(sym,e){sym.$("YearText").html("1991");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",13000,function(sym,e){sym.$("YearText").html("1992");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",13500,function(sym,e){sym.$("YearText").html("1993");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",14000,function(sym,e){sym.$("YearText").html("1994");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",14500,function(sym,e){sym.$("YearText").html("1995");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",15000,function(sym,e){sym.$("YearText").html("1996");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",15500,function(sym,e){sym.$("YearText").html("1997");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",16000,function(sym,e){sym.$("YearText").html("1998");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",16500,function(sym,e){sym.$("YearText").html("1999");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",17000,function(sym,e){sym.$("YearText").html("2000");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",17500,function(sym,e){sym.$("YearText").html("2001");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",18000,function(sym,e){sym.$("YearText").html("2002");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",18500,function(sym,e){sym.$("YearText").html("2003");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",19000,function(sym,e){sym.$("YearText").html("2004");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",19500,function(sym,e){sym.$("YearText").html("2005");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",20000,function(sym,e){sym.$("YearText").html("2006");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",20500,function(sym,e){sym.$("YearText").html("2007");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",21000,function(sym,e){sym.$("YearText").html("2008");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",21500,function(sym,e){sym.$("YearText").html("2009");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",22000,function(sym,e){sym.$("YearText").html("2010");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",22500,function(sym,e){sym.$("YearText").html("2011");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",23000,function(sym,e){sym.$("YearText").html("2012");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",23500,function(sym,e){sym.$("YearText").html("2013");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_map-txt}","click",function(sym,e){window.open("http://dsph-dev.provost.uiowa.edu/IWP","_self");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M1970}","click",function(sym,e){sym.stop('1970');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M1971}","click",function(sym,e){sym.stop('1971');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M1972}","click",function(sym,e){sym.stop('1972');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M1973}","click",function(sym,e){sym.stop('1973');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M1974}","click",function(sym,e){sym.stop('1974');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M1975}","click",function(sym,e){sym.stop('1975');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M1976}","click",function(sym,e){sym.stop('1976');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M1977}","click",function(sym,e){sym.stop('1977');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M1978}","click",function(sym,e){sym.stop('1978');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M1979}","click",function(sym,e){sym.stop('1979');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M1980}","click",function(sym,e){sym.stop('1980');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M1981}","click",function(sym,e){sym.stop('1981');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M1982}","click",function(sym,e){sym.stop('1982');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M1983}","click",function(sym,e){sym.stop('1983');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M1984}","click",function(sym,e){sym.stop('1984');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M1985}","click",function(sym,e){sym.stop('1985');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M1986}","click",function(sym,e){sym.stop('1986');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M1987}","click",function(sym,e){sym.stop('1987');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M1988}","click",function(sym,e){sym.stop('1988');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M1989}","click",function(sym,e){sym.stop('1989');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M1990}","click",function(sym,e){sym.stop('1990');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M1991}","click",function(sym,e){sym.stop('1991');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M1992}","click",function(sym,e){sym.stop('1992');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M1993}","click",function(sym,e){sym.stop('1993');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M1994}","click",function(sym,e){sym.stop('1994');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M1995}","click",function(sym,e){sym.stop('1995');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M1996}","click",function(sym,e){sym.stop('1996');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M1997}","click",function(sym,e){sym.stop('1997');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M1998}","click",function(sym,e){sym.stop('1998');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M1999}","click",function(sym,e){sym.stop('1999');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M2000}","click",function(sym,e){sym.stop('2000');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M2001}","click",function(sym,e){sym.stop('2001');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M2002}","click",function(sym,e){sym.stop('2002');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M2003}","click",function(sym,e){sym.stop('2003');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M2004}","click",function(sym,e){sym.stop('2004');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M2005}","click",function(sym,e){sym.stop('2005');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M2006}","click",function(sym,e){sym.stop('2006');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M2007}","click",function(sym,e){sym.stop('2007');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M2008}","click",function(sym,e){sym.stop('2008');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M2009}","click",function(sym,e){sym.stop('2009');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M2010}","click",function(sym,e){sym.stop('2010');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M2011}","click",function(sym,e){sym.stop('2011');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M2012}","click",function(sym,e){sym.stop('2012');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_M2013}","click",function(sym,e){sym.stop('2013');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"document","compositionReady",function(sym,e){});
//Edge binding end
})("stage");
//Edge symbol end:'stage'

//=========================================================

//Edge symbol: 'Marker1966'
(function(symbolName){})("Marker1966");
//Edge symbol end:'Marker1966'
})(jQuery,AdobeEdge,"EDGE-152640909");